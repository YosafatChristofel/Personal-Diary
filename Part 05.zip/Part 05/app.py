from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
from datetime import datetime
import os

app = Flask(__name__)

# MongoDB connection string
connection_string = 'mongodb+srv://test:sparta@cluster0.pstotr8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
client = MongoClient(connection_string)
db = client.dbsparta

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/diary', methods=['GET'])
def show_diary():
    articles = list(db.diary.find({}, {'_id': False}))
    for article in articles:
        article['imageUrl'] = f'/static/{article["file"]}'
        article['profileImageUrl'] = f'/static/{article["profile_image"]}'
    return jsonify({'articles': articles})

@app.route('/diary', methods=['POST'])
def save_diary():
    title_receive = request.form['title_give']
    content_receive = request.form['content_give']
    file = request.files['file_give']
    profile_file = request.files['profile_file_give']

    today = datetime.now()
    mytime = today.strftime('%Y-%m-%d-%H-%M-%S')

    # Handling diary image
    extension = file.filename.rsplit('.', 1)[-1]
    filename = f'file-{mytime}.{extension}'
    file_path = os.path.join('static', filename)
    file.save(file_path)

    # Handling profile image
    profile_extension = profile_file.filename.rsplit('.', 1)[-1]
    profile_filename = f'profile-{mytime}.{profile_extension}'
    profile_path = os.path.join('static', profile_filename)
    profile_file.save(profile_path)

    time = today.strftime('%Y.%m.%d')

    doc = {
        'file': filename,
        'profile_image': profile_filename,
        'title': title_receive,
        'content': content_receive,
        'time': time,
    }
    db.diary.insert_one(doc)

    return jsonify({'msg': 'Upload complete!', 'file': filename, 'profile_image': profile_filename})

if __name__ == '__main__':
    # Ensure the 'static' folder is created
    if not os.path.exists('static'):
        os.makedirs('static')
    app.run('0.0.0.0', port=5000, debug=True)
